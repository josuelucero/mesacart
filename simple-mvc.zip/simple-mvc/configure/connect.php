<?php
error_reporting(0);
session_start();
$sessid = session_id();
// $host = '198.91.81.8';
// $username = 'lucerox3_admin';
// $password = 'password';
// $dbname = 'lucerox3_test';
$host = 'localhost';
$username = 'root';
$password = 'root';
$dbname = 'mono';
$dsn = "mysql:host=$host;dbname=$dbname";
$connect = new PDO($dsn, $username, $password);
$prefix = '3321_';
$buyers = '3321_buyers';
$cartitems = '3321_cartitems';
$category = '3321_category';
$ecadmin = '3321_ecadmin';
$inv = '3321_inv';
$orders = '3321_orders';
$products = '3321_products';
$spec = '3321_spec';
$zipcodes = '3321_zipcodes';
$attributes= '3321_attributes';
$maincategory = '3321_maincategory';
$coupons = '3321_coupons';
$rating = '3321_ratings';
$root = 'http://localhost/simple-mvc/';
// $root = 'http://lucero.x10host.com/mono/';

?>
