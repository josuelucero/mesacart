<?php
  require_once 'configure/connect.php';
  require_once 'load.php';
  require_once 'controllers/Controller.php';
  require_once 'models/model.php';
  // require_once 'controllers/Etheral.php';
  require_once 'controllers/Astral.php';
  require_once 'controllers/Read.php';
  require_once 'controllers/Dimension.php';
  require_once 'controllers/Identity.php';
  require_once 'controllers/Lens.php';
  new Controller();
?>
