<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="public/mono-css/tops.css">
  <link rel="icon" href="#" alt="mono logo">
  <title>mono | home</title>
</head>

<body>
  <div class="wrapper">
    <aside>
      <div class="tops">
        <h3>tops</h3>
        <ul>
          <li>
            <label class="checkbox">t-shirts
              <input type="checkbox">
              <span class="checkmark"></span>
            </label>
          </li>
          <li>
            <label class="checkbox">long sleeve
              <input type="checkbox">
              <span class="checkmark"></span>
            </label>
          </li>
        </ul>
      </div>
      <div class="bottoms">
        <h3>bottoms</h3>
        <ul>
          <li>
            <label class="checkbox">chinos
              <input type="checkbox">
              <span class="checkmark"></span>
            </label>
          </li>
          <li>
            <label class="checkbox">jeans
              <input type="checkbox">
              <span class="checkmark"></span>
            </label>
          </li>
        </ul>
      </div>
      <div class="sale">
        <h3>on sale</h3>
        <ul>
          <li>
            <label class="checkbox">yes
                <input type="checkbox">
                <span class="checkmark"></span>
              </li>
              <li>
                <label class="checkbox">no
                <input type="checkbox">
                <span class="checkmark"></span>
              </li>
            </ul>
        </div>
    </aside>
      <div class="right">
        <header>
          <nav>
            <ul>
              <li class="nav_logo">
                <a href="">
                  <img class="logo" src="admin/images/svgs/logo.svg" alt="mono logo">
                </a>
              </li>
              <li class="nav_primary">
                <a href="<?php echo $root.'category.php?catid=1'?>">
                  tops
                </a>
                <a href="<?php echo $root.'category.php?catid=2'?>">
                  bottoms
                </a>
              </li>
              <li class="nav_secondary">
                <form action="search.php" method='post' name='formname'>
                  <div class='search'>
                    <input type="text" name="query" placeholder="search.." id ='qry' onkeyup='makeRequest();'/>
                    <i class='fas fa-search icon'></i>
                  </div>
                </form>
							</li>
            </ul>
          </nav>
        </header>
        <main>
          <div class="grid">

            <?php
            // $statement = $connect->prepare("
            //   select $products.id, $products.name, $products.price
            //   from $products limit 8
            // ");
            //
            // $statement->execute();
            // $results = $statement->fetchAll(PDO::FETCH_OBJ);
            ?>

            <?php foreach($results as $result): ?>
              <?php
                $pid = $result->id;
                $img = $pid.'/1.jpg';
                $name = $result->name;
                $price = $result->price;
              ?>
              <div class='grid_item'>
                <div class='product-card'>
                  <div class='product-card-image' style="background:url(<?php echo $root.''.$img; ?>)center;background-size:cover;">
                    <a class="image-link" href="<?php echo 'product.php?pid='.$pid; ?>"></a>
                    <!-- <img src='<?php #echo $root.''.$img; ?>' alt='<?php #echo $name; ?>'> -->
                  </div>
                  <div class='product-car-info'>
                    <a href='product.php?pid=<?php echo $pid; ?>'>
                      <p class='title'><?php echo $name; ?></p>
                    </a>
                    <p class='price'><?php echo '$'.$price; ?></p>
                    <div class='product-card-icons'>
                      <i class='fas fa-cart-plus'></i>
                      <i class='far fa-heart'></i>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </main>
      </div>
  </div>
  <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>


  <!-- <script src="javascript/main.js"></script> -->
</body>
</html>
