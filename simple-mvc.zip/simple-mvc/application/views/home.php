<!doctype html>

<html lang="en">
<head>
   <meta charset="utf-8">
   <title>home</title>
</head>
<body>
   <h1> Hello From the View </h1>
   <?php echo $first . ' ' . $last; ?>
</body>
</html>
