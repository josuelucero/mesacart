<?php

class Lens extends Controller {
  function __construct() {
    $this->load = new Load();
    $this->model = new Model();
    // determine what page you're on
    $this->lens();
  }

  function lens() {
    $data = null;
    $this->load->view('lens.html', $data);
  }
}
