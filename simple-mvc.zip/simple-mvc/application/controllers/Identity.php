<?php

class Identity extends Controller {
  function __construct() {
    $this->load = new Load();
    $this->model = new Model();
    // determine what page you're on
    $this->identity();
  }

  function identity() {
    $data = null;
    $this->load->view('identity.html', $data);
  }
}
