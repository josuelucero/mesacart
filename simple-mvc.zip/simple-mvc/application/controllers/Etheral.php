<?php

class Etheral extends Controller {
  function __construct() {
    $this->load = new Load();
    $this->model = new Model();
    // determine what page you're on
    $this->etheral();
  }

  function etheral() {
    $data = null;
    $this->load->view('etheral.html', $data);
  }
}
