<?php

class Dimension extends Controller {
  function __construct() {
    $this->load = new Load();
    $this->model = new Model();
    // determine what page you're on
    $this->dimension();
  }

  function dimension() {
    $data = null;
    $this->load->view('dimension.html', $data);
  }
}
