<?php

class Read extends Controller {
  function __construct() {
    $this->load = new Load();
    $this->model = new Model();
    // determine what page you're on
    $this->read();
  }

  function read() {
    $data = null;
    $this->load->view('read.html', $data);
  }
}
