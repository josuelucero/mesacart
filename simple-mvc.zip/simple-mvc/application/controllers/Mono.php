<?php

class Mono extends Controller {

  function __construct() {
    $this->load = new Load();
    $this->model = new Mono_info();
    $this->mono();
  }

  function mono() {
    $data = $this->model->new_names();
    $this->load->view('home.php', $data);
  }

}
