<?php

class Product extends Controller {
  function __construct() {
    $this->load = new Load();
    $this->model = new Model();
    // determine what page you're on
    $this->products();
  }

  function products() {
    $data = $this->model->product_info();
    $this->load->view('product.php', $data);
  }
}
