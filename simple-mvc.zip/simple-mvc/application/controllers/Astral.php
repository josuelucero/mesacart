<?php

class Astral extends Controller {
  function __construct() {
    $this->load = new Load();
    $this->model = new Model();
    // determine what page you're on
    $this->astral();
  }

  function astral() {
    $data = null;
    $this->load->view('astral.html', $data);
  }
}
