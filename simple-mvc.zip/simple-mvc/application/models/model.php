<?php

class Model {

  public function name() {
    return array(
       'first' => 'josue',
       'last'  => 'lucero'
    );
  }

  public function product() {
    return $this->db->query('
      select * from names limit 1
    ');
  }
}
