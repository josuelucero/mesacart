<?php
require_once '../../configure/connect.php';
// class Mono_info extends Model {
//   public $results;
//
//   public function monoinfo() {
//
//     $statement = $connect->prepare("
//       select * from $products
//     ");
//
//     $statement->execute();
//     $results = $statement->fetchAll(PDO::FETCH_OBJ);
//
//     return $results;
//   }
//
// }
// $mono = new Mono_info;

// function product($connect) {
//   $statement = $connect->prepare("
//     select * from $products
//   ");
//   $statement->execute();
//   return fetchAll(PDO::FETCH_OBJ);
// }
require_once 'Model.php';
class Mono_info extends Model {

  public function new_names() {
    return array(
       'first'  => 'John',
       'last'  => 'Doe'
    );
  }

  public function product($connect) {
    $statement = $connect->prepare("
      select $products.name,$products.price
      from $products limit 1
    ");

    $statement->execute();
    $results = $statement->fetchAll(PDO::FETCH_OBJ);

    echo '<pre>', print_r($results, 1) , '</pre>';

    return $results;

  }

}

echo product();

// $statement = $connect->prepare("
//   select $products.name,$products.price
//   from $products limit 1
// ");
//
// $statement->execute();
// $results = $statement->fetchAll(PDO::FETCH_OBJ);
// // $results = $statement->fetchAll();
//
// echo '<pre>', print_r($results, 1) , '</pre>';
?>
